import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# Bot token comes from an environment variable, never hardcoded here.
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")

# --- Your links ---
COMMUNITY_CHAT_URL = "https://t.me/+yxoJp8zrYeU0Mjlk"
ANNOUNCEMENTS_URL = "https://t.me/RegulardudeRG"
X_URL = "https://x.com/regulardudecoin?s=11"

WELCOME_TEXT = (
    "Welcome to $RGDUDE 🚀\n\n"
    "Official portal for everything below 👇"
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("💬 Community Chat", url=COMMUNITY_CHAT_URL)],
        [InlineKeyboardButton("📢 Announcements", url=ANNOUNCEMENTS_URL)],
        [InlineKeyboardButton("🐦 X (Twitter)", url=X_URL)],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(WELCOME_TEXT, reply_markup=reply_markup)


def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN environment variable is not set. "
            "Set it in your hosting platform's environment variables."
        )

    application = Application.builder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start))

    logger.info("Bot starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
